<div class="container" style="border: #999 solid 2px;">
	<br />
	<?php
		$this->load->view('admin/message');
	?>
    <div class="sidebar col-md-12 col-sm-12 col-xs-12" >	
        <?php
			$this->load->view('admin/order/listed');
        ?>
    </div>   
</div>     
