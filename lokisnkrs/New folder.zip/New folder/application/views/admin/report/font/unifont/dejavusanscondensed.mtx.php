<?php
$name='DejaVuSansCondensed';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 4,
  'FontBBox' => '[-918 -415 1513 1167]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='C:\xampp\htdocs\loki_site\admincp\fpdf/font/unifont/DejaVuSansCondensed.ttf';
$originalsize=643852;
$fontkey='dejavu';
?>