<!--FOOTER : START -->
<footer>
	<div class="container">
    	<span><br/></span>
        <h4>CỬA HÀNG BÁN GIÀY CHÍNH HÃNG LOKI SNEAKER</h4>
                    
        <div class="footer-info text-left">
        	Chuyên phân phối giày từ các thương hiệu Adidas, Asic, Converse,...
        </div>
        <div class="footer-info text-left">
        	Cam kết bán giày chính hãng, phát hiện fake hoàn tiền 100%
        </div>
        <br/><br/>
	</div>
</footer>
<!--FOOTER : END -->