<div class="container-fluid">
        <div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1" style="margin-top:20px;"> 

<?php $this->load->view('admin/product/listed');?>
</div>
</div>