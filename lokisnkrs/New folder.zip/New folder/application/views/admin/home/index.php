<div class="container-fluid">
	<?php
		$this->load->view('admin/message');
	?>
	<div align="center" align="center" class="col-md-8 col-sm-12 col-xs-12 col-md-offset-2" 
    style=" height:70px; margin-top:20px; border: #000 dashed 2px">
    	<h2><strong style="">Xin chào, <?php echo $admin_name?>!</strong></h2>
    </div><br />
	<h3 align="center" class="col-md-12 col-sm-12 col-xs-12" style="margin-top:40px;"><strong>CỬA HÀNG GIÀY THỂ THAO LOKISNEAKER</strong></h3>
    <h3 align="center" class="col-md-12 col-sm-12 col-xs-12"><strong>__Uy tín dựa trên chất lượng__</strong></h3>
	<center><p class="col-md-12 col-sm-12 col-xs-12" style="font-size:16px;"><br/>---------------------------------------------------------------------------------------------<br/><br/>
    Được thành lập từ năm 2014, LokiSneaker ngày càng được biết đến như một cửa hàng uy tín chuyên các loại hàng chính hãng ( originals / authentic ) của các thương hiệu nổi tiếng trên thế giới: Nike, Adidas, Lacoste, DC, Fox, Vans, Reebok, NewBalance, Columbia,... với chất lượng đảm bảo và giá cả cạnh tranh nhất.<br/><br/>
    LokiSneaker xin cam kết chỉ bán hàng chính hãng - FAKE xin tặng luôn giày, đền tiền x10 , giao hàng đúng hạn và kịp thời cho khách hàng ở xa, phục vụ khách hàng cả trước và sau khi mua hàng.<br/>
    </p></center></div>
    <center><img src="<?php echo base_url()?>upload/pt2.png" width="566" height="234"></center>

                    