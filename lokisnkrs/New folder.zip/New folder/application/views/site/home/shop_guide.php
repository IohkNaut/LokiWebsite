<div class="container-fluid">
	<h3 align="center" class="col-md-12 col-sm-12 col-xs-12"><strong>HƯỚNG DẪN MUA HÀNG</strong></h3>

    <p style=" text-align:justify; "><strong style="font-size:16px; text-decoration:underline;">Cách 1:</strong> Gọi điện thoại đến tổng đài 090.999.9999 từ 8g30-22g (cả CN & ngày lễ) nhân viên chúng tôi luôn sẵn sàng phục vụ bạn.</p>
    <p style=" text-align:justify; "><strong style="font-size:16px; text-decoration:underline;">Cách 2:</strong> Đặt mua hàng trên website.</p>
    <p style="font-size:16px;"><strong>Bước 1: Tìm sản phẩm cần mua</strong></p>
    <p style=" text-align:justify;">- Click vào "Sản phẩm" để vào trang tất cả sản phẩm sau đó có thể tìm sản phẩm theo các danh mục.</p>
    <p style=" text-align:justify;">- Tìm nhanh khi đã biết tên sản phẩm. Bạn chỉ cần gõ "tên sản phẩm" vào box tìm kiếm, hệ thống sẽ gợi ý bạn tên sản phẩm đúng nhất hiện có trong hệ thống.</p>
    <p style="font-size:16px;"><strong>Bước 2: Chọn sản phẩm cần mua</strong></p>
    <p style=" text-align:justify;">- Click vào sản phẩm cần mua, chọn size, chọn số lượng<br/>- Click Thêm vào giỏ</p>
    <p style="font-size:16px;"><strong>Bước 3: Thanh toán</strong></p>
    <p style=" text-align:justify;">- Kiểm tra lại thông tin giỏ hàng sau đó đăng nhập để thanh toán.<br />
- Click thanh toán, nhập thông tin nhận hàng và đặt hàng.<br/>
    
<strong>Lưu ý:</strong>/ 
- Sau khi đặt hàng nhân viên cửa hàng sẽ liên lạc với bạn để xác nhận đơn hàng trong vòng 24 giờ, quý khách vui lòng không tắt điện thoại trong thời gian này.<br />
- Nếu muốn huỷ đơn hàng quý khách vui lòng gọi hotline 0909.999.9999 để báo cho nhân viên.<br /></p>
	<p style="font-size:16px;"><strong>Xin chân thành cảm ơn quý khách!</strong></p>
</div>
                    