<div class="container-fluid">
	<h3 align="center" class="col-md-12 col-sm-12 col-xs-12"><strong>LIÊN HỆ</strong></h3>

    <center>
    <p style=" text-align:justify; "><strong style="font-size:16px;">Hotline: 090.999.9999</strong></p>
    <p style=" text-align:justify; "><strong style="font-size:16px;">Địa chỉ: khu phố 6, phường Linh Trung, quận Thủ Đức, tp.HCM</strong></p>
    <p style=" text-align:justify; "><strong style="font-size:16px; text-decoration:underline;">Cửa hàng bán giày thể thao chính hãng LOKI SNEAKER</strong></p>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.2285080099805!2d106.80154771472982!3d10.870216960428085!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317527587ba04377%3A0x4ea5c6ca79f1ff59!2sUniversity+Of+Information+Technology!5e0!3m2!1sen!2s!4v1495880552257" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe> <br/>
<strong style="font-size:16px;"><br/>Xin hân hạnh được phục vụ quý khách!</strong> 
	</center>
</div>
                    