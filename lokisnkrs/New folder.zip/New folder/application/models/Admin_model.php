<?php
class Admin_model extends MY_Model {
	var $table = 'admin';
	var $key = 'admin_id';
}