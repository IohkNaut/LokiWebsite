<?php
class Member_model extends MY_Model {
	var $table = 'member';
	var $key = 'member_id';
}