<?php
class Order_model extends MY_Model {
	var $table = 'orders';
	var $key = 'orders_id';
}