<?php
class News_model extends MY_Model {
	var $table = 'news';
	var $key = 'news_id';
}