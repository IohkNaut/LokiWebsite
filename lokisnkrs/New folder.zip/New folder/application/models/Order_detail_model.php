<?php
class Order_detail_model extends MY_Model {
	var $table = 'orders_detail';
	var $key = 'od_detail_id';
}