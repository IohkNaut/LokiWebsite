<?php
$config = array (
	'admin' => array('index'),
	'catalog' => array('index'),
	'product' => array('index'),
	'member' => array('index'),
	'news' => array('index'),
	'order' => array('index', 'new_order', 'cancel_order'),
	'report' => array('index')
);